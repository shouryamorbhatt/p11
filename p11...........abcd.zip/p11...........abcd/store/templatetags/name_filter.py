from django import template

register = template.Library()

@register.filter(name='name_cart')
def name_cart(name):
    s = 'Anonymous'
    if name:
        s= name
        return (s+" 's")
    else:
        return (s+" 's")